export class Channel {
    
    channelId: number;
    channelName: string;    

    constructor(channel?){
    
    this.channelId = channel!=undefined ? channel.channelId : 0;
    this.channelName = channel!=undefined ? channel.channelName : '';
   
    }
}