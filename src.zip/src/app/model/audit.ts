export class Audit {
        auditId: number;
        channelId: number;
        channelName: string;
        cycleId: number;
        vendorId: number;
        vendorName: string;
        forwarderId: number;
        forwarderName: string;
        status: number;
        auditorDtos?: any;
        message: string;
        auditCompletionDate: string;

        constructor(audit?){
        this.auditId = audit!=undefined ? audit.auditId :0;
        this.channelId = audit!=undefined ? audit.channelId : 0;
        this.channelName = audit!=undefined ? audit.channelName : '';
        this.cycleId = audit!=undefined ? audit.cycleId : 0;
        this.vendorId = audit!=undefined ? audit.vendorId : 0;
        this.vendorName = audit!=undefined ? audit.vendorName : '';
        this.forwarderId = audit!=undefined ? audit.forwarderId : 0;
        this.forwarderName = audit!=undefined ? audit.forwarderName : '';
        this.status = audit!=undefined ? audit.status : -1;
        this.auditorDtos = audit!=undefined ? audit.auditorDtos : undefined;
        this.message = audit!=undefined ? audit.message : '';
        this.auditCompletionDate = audit!=undefined ? audit.auditCompletionDate : '';
        }
    }