export class Vendor {

    vendorId: number;
    vendorName: string;  

    constructor(vendor?){
   
    this.vendorId = vendor!=undefined ? vendor.vendorId : 0;
    this.vendorName = vendor!=undefined ? vendor.vendorName : '';
   
    }
}