import { Component, OnInit } from '@angular/core';
import { Audit } from '../../model/audit';
import { AuditService } from '../../services/audit.service';
import { Vendor } from '../../model/vendor';
import { Channel } from '../../model/channel';
import { ChannelService } from '../../services/channel.service';
import { VendorService } from '../../services/vendor.service';
import { SelectItem } from 'primeng/components/common/selectitem';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-audits',
  templateUrl: './audits.component.html',
  styleUrls: ['./audits.component.css']
})
export class AuditsComponent implements OnInit {

  displayDialog: boolean;
  selectedAudit: Audit;
  selectedColumns: any[];
  audits: Audit[];
  vendors: Vendor[];
  channels: Channel[];
  vendorsList: SelectItem[];
  filterVendorsList: SelectItem[];
  cyclesList: SelectItem[];;
  channelsList: SelectItem[];
  audit: Audit;
  newAudit: boolean;
  cols: any[];

  constructor(private auditService: AuditService,
    private channelService: ChannelService,
    private vendorService: VendorService,private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
      this.getAllAudits();
      this.vendorsList = [];
      this.channelsList = [];
      this.filterVendorsList = [];
      this.cols = [
          { field: 'auditId', header: 'Audit Id' },
          { field: 'channelName', header: 'channel Name' },
          { field: 'cycleId', header: 'cycle Id' },
          { field: 'vendorName', header: 'vendorName' },
          { field: 'forwarderName', header: 'forwarderName' },
          { field: 'status', header: 'status' },
          { field: 'auditCompletionDate', header: 'CompletionDate' }
      ];
      this.selectedColumns = this.cols;
      this.cyclesList = [
        {label:'Please Select', value:0},
        {label:'Cycle 1', value:1},
        {label:'Cycle 2', value:2},
        {label:'Cycle 3', value:3},
        {label:'Cycle 4', value:4}
      ];
      this.getAllChannels();
      this.getAllVendors();
  }

  getAllAudits(){
    this.auditService.getAllAudits().subscribe(
        val => {
            this.audits = val;
          this.audits.forEach((audit)=>{
              
          });
        },
        (error) => {
          console.error('Oops, failed !!!', error);
        });
  }
  getAllVendors(){
      this.vendorsList = [];
      this.vendorsList.push({label:'Please Select', value:0});
    this.vendorService.getAllVendorss().subscribe(
        val => {
            this.vendors = val;
            this.vendors.forEach((vendor)=>{

                this.vendorsList.push({label:vendor.vendorName, value:vendor.vendorId});
                this.filterVendorsList.push({label:vendor.vendorName, value:vendor.vendorName});
            });
           
        },
        (error) => {
          console.error('Oops, failed !!!', error);
        });
  }
  getAllChannels(){
      this.channelsList = [];
      this.channelsList.push({label:'Please Select', value:0});
    this.channelService.getAllChannels().subscribe(
        val => {
            this.channels = val;
            this.channels.forEach((channel)=>{
                this.channelsList.push({label:channel.channelName, value:channel.channelId});
            });
            
        },
        (error) => {
          console.error('Oops, failed!!!', error);
        });
  }
  showDialogToAdd() {
      this.newAudit = true;
      this.audit = new Audit();
      this.displayDialog = true;
  }

  save() {
    if(this.audit.auditId==0){
      this.audit.auditCompletionDate = this.dateFormat(this.audit.auditCompletionDate);
      console.log('this.audit.auditCompletionDate='+this.audit.auditCompletionDate);
      this.auditService.createAudits(this.audit).subscribe(
        val => {
           
          alert(val.message);
          this.getAllAudits();
          this.displayDialog = false;
            
        },
        (error) => {
          console.error('Oops, failed!!!', error);
        });
    }
    else{
      this.audit.auditCompletionDate = this.dateFormat(this.audit.auditCompletionDate);
      console.log('this.audit.auditCompletionDate='+this.audit.auditCompletionDate);
        this.auditService.updateAudits(this.audit).subscribe(
            val => {
               
              alert(val.message);
              this.getAllAudits();
              this.displayDialog = false;
                
            },
            (error) => {
              console.error('Oops, failed!!!', error);
            });

    }

     
  }

  dateFormat(date): string{
    let d = new Date(Date.parse(date));
    const formattedDate =`${d.getMonth()+1}/${d.getDate()}/${d.getFullYear()}`;
   console.log('formattedDate='+formattedDate);
  //console.log('this.audit.auditCompletionDate='+this.audit.auditCompletionDate);
  return formattedDate;
  }

  delete() {
    this.auditService.deleteAudits(this.audit).subscribe(
        val => {
           
          alert(val.message);
          this.getAllAudits();
          this.displayDialog = false;
            
        },
        (error) => {
          console.error('Oops, failed!!!', error);
        });

      this.displayDialog = false;
  }

  onRowSelect(event) {
     /*  this.newCar = false;
      this.car = this.cloneCar(event.data); */
     
     
      console.log('select event');
      console.log('event.data'+JSON.stringify(event.data));
      this.audit = new Audit(event.data);
      this.displayDialog = true;
  }
  goToAuditing(index){
console.log('index=='+index);
const auditId = this.audits[index].auditId;
const vendorName = this.audits[index].vendorName;
this.router.navigate(['auditing'], { queryParams: { auditId: auditId,vendorName: vendorName } });
  }

/*   cloneCar(c: Car): Car {
      let car = {};
      for (let prop in c) {
          car[prop] = c[prop];
      }
      return car;
  } */
}
