import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {TableModule} from 'primeng/table'; 
import {PaginatorModule} from 'primeng/paginator'; 
import {DialogModule} from 'primeng/dialog'; 
import {CalendarModule} from 'primeng/calendar';
import {ButtonModule} from 'primeng/button';
import {MultiSelectModule} from 'primeng/multiselect';
import {HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AppRouterModule } from './app-router/app-router.module';
import { AuditsComponent } from './components/audits/audits.component';
import { AuditService } from './services/audit.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { VendorService } from './services/vendor.service';
import { ChannelService } from './services/channel.service';
import { DatePipe } from '@angular/common';
import { AuditingComponent } from './components/auditing/auditing.component';



@NgModule({
  declarations: [
    AppComponent,
    SideNavComponent,
    DashboardComponent,
    AuditsComponent,
    AuditingComponent
  ],
  imports: [
    DialogModule,
    BrowserModule,
    ButtonModule,
    MultiSelectModule,
    BrowserAnimationsModule,
    AppRouterModule,
    TableModule,
    HttpModule,
    HttpClientModule,
    PaginatorModule,
    CalendarModule
  ],
  providers: [AuditService,VendorService,ChannelService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
