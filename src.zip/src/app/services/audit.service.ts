import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';
import {environment} from '../../environments/environment';
import { Audit } from '../model/audit';

@Injectable()
export class AuditService {
  private host = 'http://localhost:8021';
  private path = '/api/audit';
  constructor(private http: HttpClient) {
  }

  createAudits(audit: Audit): Observable<Audit> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post(this.host + this.path +'/save', audit, {headers})
      .map(value => new Audit(value));
  }
  updateAudits(audit: Audit): Observable<Audit> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put(this.host + this.path +'/update', audit, {headers})
      .map(value => new Audit(value));
  }
  deleteAudits(audit: Audit): Observable<Audit> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put(this.host + this.path +'/delete', audit, {headers})
      .map(value => new Audit(value));
  }
  getAllAudits(): Observable<Array<Audit>> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    console.log('reached');
    return this.http
      .get<Array<Audit>>(
        this.host + this.path , {headers})
      .map((audits: Audit[]) => audits.map((audit: Audit) => new Audit(audit)));
  }

}
