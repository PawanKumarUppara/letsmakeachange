import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';
import {environment} from '../../environments/environment';
import { Channel } from '../model/channel';
import { Vendor } from '../model/vendor';

@Injectable()
export class VendorService {
  private host = 'http://localhost:8021';
  private path = '/api/vendor';
  constructor(private http: HttpClient) {
  }

  getAllVendorss(): Observable<Array<Vendor>> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    console.log('reached');
    return this.http
      .get<Array<Vendor>>(
        this.host + this.path , {headers})
      .map((vendors: Vendor[]) => vendors.map((vendor: Vendor) => new Vendor(vendor)));
  }

}
