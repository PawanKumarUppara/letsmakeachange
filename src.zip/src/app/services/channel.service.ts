import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';
import {environment} from '../../environments/environment';
import { Channel } from '../model/channel';

@Injectable()
export class ChannelService {
  private host = 'http://localhost:8021';
  private path = '/api/channel';
  constructor(private http: HttpClient) {
  }

  getAllChannels(): Observable<Array<Channel>> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    console.log('reached');
    return this.http
      .get<Array<Channel>>(
        this.host + this.path , {headers})
      .map((channels: Channel[]) => channels.map((channel: Channel) => new Channel(channel)));
  }

}
