import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


import { AppPreloadingStrategy } from '../preloading-strategy';
import { DashboardComponent } from '../components/dashboard/dashboard.component';
import { AuditsComponent } from '../components/audits/audits.component';
import { AuditingComponent } from '../components/auditing/auditing.component';

const routes: Routes = [
  { path: '', redirectTo: '/auditing', pathMatch: 'full' },
  {path: 'dashboard',  component: DashboardComponent},
  {path: 'audits',  component: AuditsComponent},
  {path: 'auditing',  component: AuditingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: false,
    enableTracing: true,
    preloadingStrategy: AppPreloadingStrategy})],
  exports: [RouterModule],
  providers: [AppPreloadingStrategy]
})
export class AppRouterModule {
}

